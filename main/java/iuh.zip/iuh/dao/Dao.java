package iuh.dao;

import java.sql.Connection;

public abstract class Dao {

}
