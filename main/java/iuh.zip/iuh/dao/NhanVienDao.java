package iuh.dao;

import iuh.connect.DatabaseConnection;

import java.sql.Connection;
import java.sql.Date;
import java.sql.PreparedStatement;
import java.sql.ResultSet;
import java.sql.SQLException;
import java.util.ArrayList;
import java.util.List;

public class NhanVienDao {

    public NhanVienDao() {
    }

    public List<String[]> getAllNhanVien() {
        List<String[]> nhanVienList = new ArrayList<>();
        String sql = "SELECT maSoNV, hoTenNV, chucVu, gioiTinh, soCCCD, ngaySinh, diaChi, soDT, matKhau FROM NhanVien WHERE daNghiViec = 0";

        try {
            Connection conn = DatabaseConnection.getConnection();
            if (conn == null || conn.isClosed()) {
                throw new SQLException("Connection is closed or not initialized.");
            }
            try (PreparedStatement stmt = conn.prepareStatement(sql);
                 ResultSet rs = stmt.executeQuery()) {

                while (rs.next()) {
                    String[] nhanVien = new String[9];
                    nhanVien[0] = rs.getString("maSoNV");
                    nhanVien[1] = rs.getString("hoTenNV");
                    nhanVien[2] = rs.getString("chucVu");
                    nhanVien[3] = rs.getString("gioiTinh");
                    nhanVien[4] = rs.getString("soCCCD");
                    nhanVien[5] = rs.getString("ngaySinh");
                    nhanVien[6] = rs.getString("diaChi");
                    nhanVien[7] = rs.getString("soDT");
                    nhanVien[8] = rs.getString("matKhau");
                    nhanVienList.add(nhanVien);
                }
            }
        } catch (SQLException e) {
            System.err.println("Lỗi truy vấn getAllNhanVien: " + e.getMessage());
            e.printStackTrace();
        }
        return nhanVienList;
    }


    public boolean addNhanVien(String maNV, String cccd, String hoTen, Date ngaySinh, int gioiTinh,
                               String soDT, String diaChi, int chucVu, String matKhau, boolean daNghiViec) {
        String sql = "EXEC sp_ThemNhanVien ?, ?, ?, ?, ?, ?, ?, ?, ?,?";
        try (Connection conn = DatabaseConnection.getConnection();
             PreparedStatement stmt = conn.prepareStatement(sql)) {
            stmt.setString(1, maNV);
            stmt.setString(2, cccd);
            stmt.setString(3, hoTen);
            stmt.setDate(4, ngaySinh);
            stmt.setInt(5, gioiTinh);
            stmt.setString(6, soDT);
            stmt.setString(7, diaChi);
            stmt.setInt(8, chucVu);
            stmt.setString(9, matKhau);
            stmt.setInt(10, daNghiViec);
            return stmt.executeUpdate() > 0;
        } catch (SQLException e) {
            e.printStackTrace();
            return false;
        }
    }

    public boolean updateNhanVien(String maNV, String cccd, String hoTen, Date ngaySinh, int gioiTinh,
                                  String soDT, String diaChi, int chucVu, String matKhau,int daNghiViec) {
        String sql = "EXEC SP_SuaNhanVien ?, ?, ?, ?, ?, ?, ?, ?, ?, ?";
        try {
            Connection conn = DatabaseConnection.getConnection();
            if (conn == null || conn.isClosed()) {
                DatabaseConnection.initializeConnection();
                conn = DatabaseConnection.getConnection();
            }
            try (PreparedStatement stmt = conn.prepareStatement(sql)) {
                stmt.setString(1, maNV);
                stmt.setString(2, cccd);
                stmt.setString(3, hoTen);
                stmt.setDate(4, new java.sql.Date(ngaySinh.getTime()));  // Chuyển đổi từ java.util.Date sang SQL Date
                stmt.setInt(5, gioiTinh);
                stmt.setString(6, soDT);
                stmt.setString(7, diaChi);
                stmt.setInt(8, chucVu);
                stmt.setString(9, matKhau);
                stmt.setInt(10, daNghiViec);

                int rowsAffected = stmt.executeUpdate();
                return rowsAffected > 0;
            }
        } catch (SQLException e) {
            System.err.println("Lỗi truy vấn updateNhanVien: " + e.getMessage());
            e.printStackTrace();
            return false;
        }
    }
    public boolean deleteNhanVien(String maNV) {
        String sql = "UPDATE NhanVien SET daNghiViec = 1 WHERE maSoNV = ?";
        try {
            Connection conn = DatabaseConnection.getConnection();
            if (conn == null || conn.isClosed()) {
                throw new SQLException("Connection is closed or not initialized.");
            }
            try (PreparedStatement stmt = conn.prepareStatement(sql)) {
                stmt.setString(1, maNV);
                int rowsAffected = stmt.executeUpdate();
                return rowsAffected > 0;
            }
        } catch (SQLException e) {
            System.err.println("Lỗi truy vấn deleteNhanVien: " + e.getMessage());
            e.printStackTrace();
            return false;
        }
    }


}